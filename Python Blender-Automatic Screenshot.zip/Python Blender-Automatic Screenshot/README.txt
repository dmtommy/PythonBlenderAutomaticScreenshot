*This is about automatic screenshots of the program by using python and blender. It can automatically capture hundreds of 3d models.

*Make sure that you have setup vscode for blender.

*Note that oversized models (more than 30MB) may cause the program to crash.

*Note that some models may be pierced in blender, resulting in incomplete screenshots.